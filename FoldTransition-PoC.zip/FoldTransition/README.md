# Fold Transition PoC

A live Android 13+ proof of concept inspired by the Galaxy Fold demo. It captures whichever screen is currently visible, freezes that frame during hinge movement, applies an AGSL transition overlay, and removes the overlay at the folded/unfolded endpoints. A secondary display is driven through Android's `Presentation` API when Samsung exposes it.

## Build and run

1. Open this folder in the latest Android Studio.
2. Let Gradle sync and install the `app` debug build on the Fold.
3. Open the app and tap **Enable live fold effect**.
4. Grant **Display over other apps** and approve Android's screen-capture prompt.
5. Return to any app or the launcher, then fold or unfold the phone.

## Important limitations

- This is not a launcher and cannot animate One UI or live apps.
- Samsung firmware decides whether the cover display is exposed as a presentation display. If it is not, the animation appears only in the app on the active screen.
- The cover-screen image uses an AGSL runtime shader for hinge-angle-driven blur and darkening, while the inner image remains sharp behind it, matching the supplied reference video.
- Secure/DRM-protected content cannot be captured by Android.

## Tuning

In `TransitionView.kt`, adjust `22.0` for blur strength and `0.68` for midpoint darkening.
