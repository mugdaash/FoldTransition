# Fold Transition PoC

A minimal Android 13+ proof of concept inspired by the Galaxy Fold demo: choose one cover-screen screenshot and one inner-screen screenshot, then interpolate between them using the physical hinge angle. A secondary display is driven through Android's `Presentation` API when Samsung exposes it.

## Build and run

1. Open this folder in the latest Android Studio.
2. Let Gradle sync and install the `app` debug build on the Fold.
3. Open the app, choose screenshots for both states, then tap **Start / refresh both screens**.
4. Fold or unfold the phone. Keep the app foregrounded during the demo.

## Important limitations

- This is not a launcher and cannot animate One UI or live apps.
- Samsung firmware decides whether the cover display is exposed as a presentation display. If it is not, the animation appears only in the app on the active screen.
- The cover-screen image uses an AGSL runtime shader for hinge-angle-driven blur and darkening, while the inner image remains sharp behind it, matching the supplied reference video.
- Use screenshots with matching wallpaper/icon arrangement for the strongest illusion.

## Tuning

In `TransitionView.kt`, adjust `36f` for blur strength and `0.035f` for the midpoint zoom pulse.
