plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mugdad.foldtransition"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mugdad.foldtransition"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
