package com.mugdad.foldtransition

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.hardware.*
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var view: TransitionView
    private lateinit var sensorManager: SensorManager
    private var presentation: FoldPresentation? = null
    private var selectingOpen = false
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        view = TransitionView(this)
        val pickClosed = Button(this).apply { text = "Choose cover screenshot"; setOnClickListener { selectingOpen=false; pick() } }
        val pickOpen = Button(this).apply { text = "Choose inner screenshot"; setOnClickListener { selectingOpen=true; pick() } }
        val demo = Button(this).apply { text = "Start / refresh both screens"; setOnClickListener { showPresentation() } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xff050509.toInt())
            addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(pickClosed); addView(pickOpen); addView(demo)
        })
        restore()
    }

    private fun pick() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
    }, 41)

    @Deprecated("legacy result keeps this project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 41 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        getPreferences(MODE_PRIVATE).edit().putString(if(selectingOpen) "open" else "closed", uri.toString()).apply()
        load(uri, selectingOpen); showPresentation()
    }

    private fun restore() {
        getPreferences(MODE_PRIVATE).getString("closed", null)?.let { load(Uri.parse(it), false) }
        getPreferences(MODE_PRIVATE).getString("open", null)?.let { load(Uri.parse(it), true) }
    }

    private fun load(uri: Uri, isOpen: Boolean) {
        contentResolver.openInputStream(uri)?.use { s ->
            val bmp = BitmapFactory.decodeStream(s)
            if (isOpen) view.open=bmp else view.closed=bmp
        }
    }

    private fun showPresentation() {
        if (view.closed == null || view.open == null) {
            Toast.makeText(this, "Choose both screenshots first", Toast.LENGTH_LONG).show()
            return
        }
        presentation?.dismiss()
        val display = (getSystemService(DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplays(android.hardware.display.DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
        if (display == null) Toast.makeText(this, "No secondary presentation display is currently available", Toast.LENGTH_LONG).show()
        else presentation = FoldPresentation(this, display, view.closed, view.open).also { it.show() }
        (view.parent as? ViewGroup)?.removeView(view)
        setContentView(view)
        window.insetsController?.hide(WindowInsets.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        val hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        if (hinge != null) sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME)
        else Toast.makeText(this, "Hinge-angle sensor is not exposed on this device", Toast.LENGTH_LONG).show()
    }
    override fun onPause() { sensorManager.unregisterListener(this); super.onPause() }
    override fun onSensorChanged(e: SensorEvent) {
        val p = (e.values[0] / 180f).coerceIn(0f,1f)
        view.progress = p; presentation?.transition?.progress = p
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

private class FoldPresentation(ctx: Context, display: Display, closed: android.graphics.Bitmap?, open: android.graphics.Bitmap?) : Presentation(ctx, display) {
    val transition = TransitionView(ctx).apply { this.closed=closed; this.open=open }
    override fun onCreate(state: Bundle?) { super.onCreate(state); window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); setContentView(transition) }
}
