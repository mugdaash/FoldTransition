package com.mugdad.foldtransition

import android.Manifest
import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val captureCode = 42
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        val status = TextView(this).apply {
            text = "Applies the fold effect to whichever screen is currently visible."
            textSize = 18f; setPadding(48, 48, 48, 48)
        }
        val start = Button(this).apply {
            text = "Enable live fold effect"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(this@MainActivity, "Allow display over other apps, return, then tap again", Toast.LENGTH_LONG).show()
                } else {
                    val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
                }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(status, LinearLayout.LayoutParams(-1, -2)); addView(start, LinearLayout.LayoutParams(-1, -2))
        })
    }

    @Deprecated("keeps the project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureCode || resultCode != RESULT_OK || data == null) return
        startForegroundService(Intent(this, CaptureOverlayService::class.java).apply {
            putExtra("resultCode", resultCode); putExtra("resultData", data)
        })
        Toast.makeText(this, "Live fold effect enabled", Toast.LENGTH_SHORT).show()
        finishAndRemoveTask()
    }
}
