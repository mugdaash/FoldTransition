package com.mugdad.foldtransition

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class TransitionView(context: Context) : View(context) {
    var frame: Bitmap? = null
        set(value) { field = value; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val target = RectF()
    private val shader = RuntimeShader("""
        uniform shader content;
        uniform float amount;
        half4 main(float2 p) {
            float r = 22.0 * amount;
            half4 c = content.eval(p) * 0.20;
            c += content.eval(p + float2( r, 0.0)) * 0.10;
            c += content.eval(p + float2(-r, 0.0)) * 0.10;
            c += content.eval(p + float2(0.0,  r)) * 0.10;
            c += content.eval(p + float2(0.0, -r)) * 0.10;
            c += content.eval(p + float2( r,  r)) * 0.10;
            c += content.eval(p + float2(-r,  r)) * 0.10;
            c += content.eval(p + float2( r, -r)) * 0.10;
            c += content.eval(p + float2(-r, -r)) * 0.10;
            c.rgb *= (1.0 - 0.68 * amount);
            return half4(c.rgb, 1.0);
        }
    """.trimIndent())
    var progress = 0f
        set(value) { field = value.coerceIn(0f, 1f); updateEffect(); invalidate() }
    private fun narrow() = width > 0 && width.toFloat() / height.toFloat() < 0.72f
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) = updateEffect()
    private fun updateEffect() {
        if (width == 0 || height == 0 || !narrow()) { setRenderEffect(null); return }
        shader.setFloatUniform("amount", sin(Math.PI * progress).toFloat().coerceIn(0f, 1f))
        setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
    }
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val bitmap = frame ?: return
        val scale = maxOf(width / bitmap.width.toFloat(), height / bitmap.height.toFloat())
        val w = bitmap.width * scale; val h = bitmap.height * scale
        target.set((width-w)/2f, (height-h)/2f, (width+w)/2f, (height+h)/2f)
        canvas.drawBitmap(bitmap, null, target, paint)
    }
}
