package com.mugdad.foldtransition

import android.content.Context
import android.graphics.*
import android.view.View

class TransitionView(context: Context) : View(context) {
    var frame: Bitmap? = null
        set(value) { field = value; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val target = RectF()
    private val shader = RuntimeShader("""
        uniform shader content;
        uniform float2 resolution;
        uniform float tiltDegrees;
        uniform float eyeDistancePx;
        uniform float hingeSide;
        uniform float blurSpread;
        uniform float darkening;

        const float GOLDEN_ANGLE = 2.39996322972865332;
        const float TWO_PI = 6.28318530717958648;

        half4 main(float2 fragCoord) {
            float2 size = resolution;
            if (size.x <= 1.0 || size.y <= 1.0) return content.eval(fragCoord);
            float tilt = radians(clamp(abs(tiltDegrees), 0.0, 45.0));
            if (tilt < 1e-5) return content.eval(fragCoord);

            float isRight = step(0.0, hingeSide);
            float hingeX = mix(0.0, size.x, isRight);
            float side = mix(1.0, -1.0, isRight);
            float d = abs(fragCoord.x - hingeX);
            float2 glass = float2(hingeX + side * d * cos(tilt), fragCoord.y);
            float gap = d * sin(tilt);
            float2 eye = size * 0.5;
            float depth = eyeDistancePx - gap;
            if (depth <= 1e-3) return half4(0.0, 0.0, 0.0, 1.0);
            float t = eyeDistancePx / depth;
            float2 hit = eye + (glass - eye) * t;
            float radius = blurSpread * gap;
            if (hit.x < -radius || hit.y < -radius ||
                hit.x > size.x + radius || hit.y > size.y + radius) {
                return half4(0.0, 0.0, 0.0, 1.0);
            }
            float atten = max(1.0 - darkening * radius, 0.0);
            if (radius < 0.5) return content.eval(hit) * half(atten);

            float tapsF = clamp(radius * 2.0, 6.0, 32.0);
            float rotation = fract(sin(dot(fragCoord, float2(12.9898, 78.233))) * 43758.5453) * TWO_PI;
            half3 sum = half3(0.0);
            float wsum = 0.0;
            for (int i = 0; i < 32; i++) {
                float fi = float(i);
                float weight = 1.0 - step(tapsF, fi);
                float radiusAtTap = radius * sqrt((fi + 0.5) / tapsF);
                float angle = fi * GOLDEN_ANGLE + rotation;
                sum += content.eval(hit + radiusAtTap * float2(cos(angle), sin(angle))).rgb * half(weight);
                wsum += weight;
            }
            return half4((sum / half(max(wsum, 1.0))) * half(atten), 1.0);
        }
    """.trimIndent())
    var progress = 0f
        set(value) { field = value.coerceIn(0f, 1f); updateEffect(); invalidate() }
    private fun narrow() = width > 0 && width.toFloat() / height.toFloat() < 0.72f
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) = updateEffect()
    private fun updateEffect() {
        if (width == 0 || height == 0 || !narrow()) { setRenderEffect(null); return }
        shader.setFloatUniform("resolution", width.toFloat(), height.toFloat())
        shader.setFloatUniform("tiltDegrees", (progress * 180f).coerceIn(0f, 45f))
        shader.setFloatUniform("eyeDistancePx", 3200f)
        shader.setFloatUniform("hingeSide", -1f)
        shader.setFloatUniform("blurSpread", 0.035f)
        shader.setFloatUniform("darkening", 0.022f)
        setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
    }
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val bitmap = frame ?: return
        val scale = maxOf(width / bitmap.width.toFloat(), height / bitmap.height.toFloat())
        val w = bitmap.width * scale; val h = bitmap.height * scale
        target.set((width-w)/2f, (height-h)/2f, (width+w)/2f, (height+h)/2f)
        canvas.drawBitmap(bitmap, null, target, paint)
    }
}
