package com.mugdad.foldtransition

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.view.View
import kotlin.math.abs

class TransitionView(context: Context) : View(context) {
    var closed: Bitmap? = null
    var open: Bitmap? = null
    var progress = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tmp = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        drawLayer(canvas, closed, 1f - smooth(progress), progress)
        drawLayer(canvas, open, smooth(progress), 1f - progress)
    }

    private fun drawLayer(canvas: Canvas, bitmap: Bitmap?, alpha: Float, distance: Float) {
        if (bitmap == null || alpha <= .001f) return
        val cover = maxOf(width / bitmap.width.toFloat(), height / bitmap.height.toFloat())
        val baseW = bitmap.width * cover
        val baseH = bitmap.height * cover
        val pulse = 1f + 0.035f * (1f - abs(progress * 2f - 1f))
        val w = baseW * pulse
        val h = baseH * pulse
        tmp.set((width-w)/2f, (height-h)/2f, (width+w)/2f, (height+h)/2f)
        paint.alpha = (255f * alpha).toInt()
        val blur = maxOf(0.1f, 36f * distance)
        paint.setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP))
        canvas.drawBitmap(bitmap, null, tmp, paint)
        paint.setRenderEffect(null)
    }

    private fun smooth(x: Float) = x * x * (3f - 2f * x)
}
