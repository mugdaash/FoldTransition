package com.mugdad.foldtransition

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.*
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.view.*
import kotlin.math.abs

class CaptureOverlayService : Service(), SensorEventListener {
    private lateinit var sensors: SensorManager
    private lateinit var windows: WindowManager
    private lateinit var displays: DisplayManager
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var latest: Bitmap? = null
    private var overlay: TransitionView? = null
    private var presentation: LivePresentation? = null
    private var effectVisible = false
    private var lastProgress = -1f

    override fun onCreate() {
        super.onCreate()
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
        windows = getSystemService(WINDOW_SERVICE) as WindowManager
        displays = getSystemService(DISPLAY_SERVICE) as DisplayManager
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel("capture", "Fold transition", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "capture").setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Fold transition active").setContentText("Watching the hinge and current screen").build())
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("resultData") ?: return START_NOT_STICKY
        projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() = stopSelf() }, Handler(Looper.getMainLooper()))
        startCapture()
        val hinge = sensors.getSensorList(Sensor.TYPE_ALL).firstOrNull {
            it.type == Sensor.TYPE_HINGE_ANGLE || it.name.contains("hinge", true) || it.stringType.contains("hinge", true)
        }
        if (hinge != null) sensors.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME)
        else problem("No hinge sensor exposed by Samsung")
        return START_STICKY
    }

    private fun startCapture() {
        val b = windows.maximumWindowMetrics.bounds
        val width = b.width().coerceAtLeast(1); val height = b.height().coerceAtLeast(1)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { ir ->
            ir.setOnImageAvailableListener({ source ->
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (!effectVisible) {
                    val plane = image.planes[0]
                    val paddedWidth = width + (plane.rowStride - plane.pixelStride * width) / plane.pixelStride
                    val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(plane.buffer)
                    latest = Bitmap.createBitmap(padded, 0, 0, width, height)
                    padded.recycle()
                }
                image.close()
            }, Handler(Looper.getMainLooper()))
        }
        virtualDisplay = projection?.createVirtualDisplay("live-fold", width, height, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val range = if (event.sensor.maximumRange <= 6.5f) Math.PI.toFloat() else 180f
        val p = (event.values[0] / range).coerceIn(0f, 1f)
        if (lastProgress < 0f) { lastProgress = p; return }
        val moving = abs(p - lastProgress) > 0.001f
        lastProgress = p
        if (p <= 0.02f || p >= 0.98f) hideEffect()
        else if (moving && latest != null) showEffect(p)
        else if (effectVisible) updateProgress(p)
    }

    private fun showEffect(p: Float) {
        if (!effectVisible) {
            effectVisible = true
            overlay = TransitionView(this).apply { frame = latest }
            val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT)
            runCatching { windows.addView(overlay, lp) }
            val current = display?.displayId
            displays.displays.firstOrNull { it.displayId != current }?.let { other ->
                presentation = runCatching { LivePresentation(this, other, latest).also { it.show() } }.getOrNull()
            }
        }
        updateProgress(p)
    }
    private fun updateProgress(p: Float) { overlay?.progress = p; presentation?.view?.progress = p }
    private fun hideEffect() {
        if (!effectVisible) return
        effectVisible = false
        overlay?.let { runCatching { windows.removeView(it) } }; overlay = null
        presentation?.dismiss(); presentation = null
    }
    private fun problem(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2,
            Notification.Builder(this, "capture").setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Fold transition unavailable").setContentText(text).build())
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onBind(intent: Intent?) = null
    override fun onDestroy() {
        hideEffect(); sensors.unregisterListener(this); virtualDisplay?.release(); reader?.close(); projection?.stop(); super.onDestroy()
    }
}

private class LivePresentation(ctx: Context, target: Display, bitmap: Bitmap?) : Presentation(ctx, target) {
    val view = TransitionView(ctx).apply { frame = bitmap }
    override fun onCreate(state: Bundle?) { super.onCreate(state); setContentView(view) }
}
